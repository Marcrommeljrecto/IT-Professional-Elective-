package com.first.gottaquizapp;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView totalQuestionsTextView;
    TextView questiontextview;
    Button AnsA,AnsB,AnsC,AnsD;
    Button submitBtn;

    int score=0;
    int totalQuestion = QuestionAnswer.question.length;
    int currentQestionIndex = 0;
    String selectedAnswer ="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        totalQuestionsTextView = findViewById(R.id.total_question);
        questiontextview = findViewById(R.id.question);
        AnsA = findViewById(R.id.ans_A);
        AnsB = findViewById(R.id.ans_B);
        AnsC = findViewById(R.id.ans_C);
        AnsD = findViewById(R.id.ans_D);
        submitBtn = findViewById(R.id.submit_btn);

        AnsA.setOnClickListener(this);
        AnsB.setOnClickListener(this);
        AnsC.setOnClickListener(this);
        AnsD.setOnClickListener(this);
        submitBtn.setOnClickListener(this);

        totalQuestionsTextView.setText("Total questions : "+totalQuestion);

        loadNewQuestion();



    }

    @Override
    public void onClick(View view) {

        AnsA.setBackgroundColor(Color.TRANSPARENT);
        AnsB.setBackgroundColor(Color.TRANSPARENT);
        AnsC.setBackgroundColor(Color.TRANSPARENT);
        AnsD.setBackgroundColor(Color.TRANSPARENT);

        Button clickedButton = (Button) view;
        if (clickedButton.getId() == R.id.submit_btn) {
            if (selectedAnswer.equals(QuestionAnswer.CorrectAnswers[currentQestionIndex])){
                score++;
            }
            currentQestionIndex++;
            loadNewQuestion();



        } else {
            //choices button clicked
            selectedAnswer = clickedButton.getText().toString();
            clickedButton.setBackgroundColor(Color.MAGENTA);
        }
    }
    void loadNewQuestion(){

        if (currentQestionIndex == totalQuestion){
            finishQuiz();
            return;
        }

        questiontextview.setText(QuestionAnswer.question[currentQestionIndex]);
        AnsA.setText(QuestionAnswer.Choices[currentQestionIndex][0]);
        AnsB.setText(QuestionAnswer.Choices[currentQestionIndex][1]);
        AnsC.setText(QuestionAnswer.Choices[currentQestionIndex][2]);
        AnsD.setText(QuestionAnswer.Choices[currentQestionIndex][3]);

    }

    void finishQuiz(){
        String passStatus = "";
        if (score > totalQuestion*0.60){
            passStatus = "Passed";
        }else{
            passStatus = "Failed";

        }
        new AlertDialog.Builder(this)
                .setTitle(passStatus)
                .setMessage("score is "+score+"out of" +totalQuestion)
                .setPositiveButton("Restart ",(dialogInterface, i) -> restartQuiz() )
                .setCancelable(false)
                .show();

    }
    void restartQuiz(){
        score = 0;
        currentQestionIndex =0;
        loadNewQuestion();
    }
}