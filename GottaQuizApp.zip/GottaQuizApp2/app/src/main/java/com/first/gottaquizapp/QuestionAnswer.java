package com.first.gottaquizapp;

public class QuestionAnswer {

    public static String question []={
            "What does CPU stand for?",
            "Which device is used to connect a computer to a network?",
            "What does HTML stand for?",
            "Which programming language is commonly used for Android development?",
            "Which of the following is NOT an input device?",
            "What type of storage is RAM?",
            "Which protocol is used to transfer web pages?",
            "What is the brain of the computer?",
            "Which of these is an operating system?",
            "Which company developed the Windows OS?"
    };

    public static String Choices [][]={
            {"Central Processing Unit", "Computer Personal Unit", "Central Program Utility", "Control Processing User"},
            {"Scanner", "Router", "Printer", "Monitor"},
            {"HyperText Markup Language", "Hyper Transfer Markup Language", "High Text Machine Language", "Home Tool Mark Language"},
            {"Python", "Java", "Swift", "PHP"},
            {"Keyboard", "Mouse", "Speaker", "Scanner"},
            {"Permanent Storage", "Optical Storage", "Temporary Memory", "Cloud Storage"},
            {"FTP", "HTTP", "SMTP", "TCP"},
            {"Hard Drive", "CPU", "RAM", "GPU"},
            {"Microsoft Word", "Google Chrome", "Windows 11", "Adobe Photoshop"},
            {"Microsoft", "Apple", "Google", "IBM"}

    };

    public static String CorrectAnswers[]= {
            "Central Processing Unit",
            "Router",
            "HyperText Markup Language",
            "Java",
            "Speaker",
            "Temporary Memory",
            "HTTP",
            "CPU",
            "Windows 11",
            "Microsoft"

    };
}
